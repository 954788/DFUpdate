//
//  ViewController.m
//  DFUpdateDemo
//
//  Created by 粱展焯 on 16/8/30.
//  Copyright © 2016年 梁展焯. All rights reserved.
//

#import "ViewController.h"
#import "DFUpdate.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidAppear:(BOOL)animated{
    
    [super viewDidAppear:animated];
    
    [[DFUpdate shareManager] checkUpdateWithShowNewContent:YES noMore:NO];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
